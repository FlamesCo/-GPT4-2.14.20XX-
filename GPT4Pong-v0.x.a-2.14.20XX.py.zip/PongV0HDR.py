import pygame
import sys

# Initialize Pygame
pygame.init()

# Set screen dimensions
width, height = 640, 480

# Define colors
white = (255, 255, 255)
black = (0, 0, 0)

# Set up the display
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Pong")

# Define paddles
paddle_width, paddle_height = 10, 60
paddle_speed = 5

# Define ball
ball_size = 10
ball_speed_x = 3
ball_speed_y = 3

# Create paddle objects and ball
left_paddle = pygame.Rect(10, height / 2 - paddle_height / 2, paddle_width, paddle_height)
right_paddle = pygame.Rect(width - 20, height / 2 - paddle_height / 2, paddle_width, paddle_height)
ball = pygame.Rect(width / 2 - ball_size / 2, height / 2 - ball_size / 2, ball_size, ball_size)

def move_paddles():
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w] and left_paddle.top > 0:
        left_paddle.move_ip(0, -paddle_speed)
    if keys[pygame.K_s] and left_paddle.bottom < height:
        left_paddle.move_ip(0, paddle_speed)
    if keys[pygame.K_UP] and right_paddle.top > 0:
        right_paddle.move_ip(0, -paddle_speed)
    if keys[pygame.K_DOWN] and right_paddle.bottom < height:
        right_paddle.move_ip(0, paddle_speed)

def move_ball():
    global ball_speed_x, ball_speed_y

    ball.move_ip(ball_speed_x, ball_speed_y)

    if ball.top <= 0 or ball.bottom >= height:
        ball_speed_y = -ball_speed_y

    if ball.colliderect(left_paddle) or ball.colliderect(right_paddle):
        ball_speed_x = -ball_speed_x

    if ball.left <= 0 or ball.right >= width:
        ball.x = width / 2 - ball_size / 2
        ball.y = height / 2 - ball_size / 2

def draw_objects():
    screen.fill(black)
    pygame.draw.rect(screen, white, left_paddle)
    pygame.draw.rect(screen, white, right_paddle)
    pygame.draw.ellipse(screen, white, ball)
    pygame.draw.aaline(screen, white, (width / 2, 0), (width / 2, height))

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    move_paddles()
    move_ball()
    draw_objects()

    pygame.display.flip()
    pygame.time.delay(16)
import pygame
import sys

# Initialize Pygame
pygame.init()

# Set screen dimensions
width, height = 640, 480

# Define colors
white = (255, 255, 255)
black = (0, 0, 0)

# Set up the display
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Pong")

# Define paddles
paddle_width, paddle_height = 10, 60
paddle_speed = 5

# Define ball
ball_size = 10
ball_speed_x = 3
ball_speed_y = 3

# Create paddle objects and ball
left_paddle = pygame.Rect(10, height / 2 - paddle_height / 2, paddle_width, paddle_height)
right_paddle = pygame.Rect(width - 20, height / 2 - paddle_height / 2, paddle_width, paddle_height)
ball = pygame.Rect(width / 2 - ball_size / 2, height / 2 - ball_size / 2, ball_size, ball_size)

def move_paddles():
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w] and left_paddle.top > 0:
        left_paddle.move_ip(0, -paddle_speed)
    if keys[pygame.K_s] and left_paddle.bottom < height:
        left_paddle.move_ip(0, paddle_speed)
    if keys[pygame.K_UP] and right_paddle.top > 0:
        right_paddle.move_ip(0, -paddle_speed)
    if keys[pygame.K_DOWN] and right_paddle.bottom < height:
        right_paddle.move_ip(0, paddle_speed)

def move_ball():
    global ball_speed_x, ball_speed_y

    ball.move_ip(ball_speed_x, ball_speed_y)

    if ball.top <= 0 or ball.bottom >= height:
        ball_speed_y = -ball_speed_y

    if ball.colliderect(left_paddle) or ball.colliderect(right_paddle):
        ball_speed_x = -ball_speed_x

    if ball.left <= 0 or ball.right >= width:
        ball.x = width / 2 - ball_size / 2
        ball.y = height / 2 - ball_size / 2

def draw_objects():
    screen.fill(black)
    pygame.draw.rect(screen, white, left_paddle)
    pygame.draw.rect(screen, white, right_paddle)
    pygame.draw.ellipse(screen, white, ball)
    pygame.draw.aaline(screen, white, (width / 2, 0), (width / 2, height))

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    move_paddles()
    move_ball()
    draw_objects()

    pygame.display.flip()
    pygame.time.delay(16)
